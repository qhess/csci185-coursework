

function color1() {
    document.querySelector("square1").onclick = 'red';
    // and change its background color...
}

function color2() {
    // target the element with the id of square2
    // and change its background color...
}

function color3() {
    // TODO
}

function color4() {
    // TODO
}

function color5() {
    // TODO
}

function color6() {
    // TODO
}